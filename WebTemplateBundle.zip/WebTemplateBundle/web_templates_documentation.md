# ModernBiz Documentation PDF

**Template Name:** ModernBiz – Responsive Business HTML Template

---

## 1. Introduction
- Modern, responsive business HTML template
- Includes: Home, About, Services, Contact pages

## 2. Template Features
- Fully responsive, mobile-first
- Hero section with modern layout
- Features, Services, Testimonials sections
- Smooth animations and hover effects
- Contact form with validation

## 3. File Structure
```
Template1_ModernBiz/
│
├── index.html
├── about.html
├── services.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
```

## 4. How to Customize
- Edit HTML content for text, headings, links
- Update CSS for colors, fonts, spacing
- Replace images in `images/` folder
- JS handles mobile menu & animations

## 5. Fonts & Icons
- Google Fonts: Inter
- FontAwesome icons

## 6. Responsive Design
- Works on Desktop, Tablet, Mobile
- Uses Flexbox & CSS Grid

## 7. Browser Compatibility
- Chrome, Firefox, Edge, Safari

## 8. License
- Personal & commercial use allowed
- Buyers can modify as needed

---

# BizPro Documentation PDF

**Template Name:** BizPro – Modern Corporate HTML Template

## 1. Introduction
- Professional business HTML template
- Includes: Home, About, Services, Contact pages

## 2. Template Features
- Hero section with image & text split
- Features, Services, Testimonials, Team sections
- Modern hover effects & animations
- Contact form & CTA sections

## 3. File Structure
```
Template2_BizPro/
│
├── index.html
├── about.html
├── services.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
```

## 4. How to Customize
- Replace text, headings, links in HTML
- Change colors & fonts in `style.css`
- Replace hero and service images in `images/` folder
- JS handles mobile menu & scroll animations

## 5. Fonts & Icons
- Google Fonts: Inter
- FontAwesome icons

## 6. Responsive Design
- Desktop, Tablet, Mobile ready
- CSS Grid & Flexbox layouts

## 7. Browser Compatibility
- Chrome, Firefox, Edge, Safari

## 8. License
- Free for personal & commercial use
- Buyers can modify

